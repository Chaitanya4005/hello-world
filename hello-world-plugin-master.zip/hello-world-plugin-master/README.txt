This plugin is written for the Jenkins plugin tutorial,
and hence it's only useful as an example, and no other
practical use.

http://wiki.jenkins-ci.org/display/JENKINS/Plugin+tutorial
